! function () {
    var e;
    e = function () {
        function e() {
            this.options_index = 0, this.parsed = []
        }
        return e.prototype.add_node = function (e) {
            return "OPTGROUP" === e.nodeName.toUpperCase() ? this.add_group(e) : this.add_option(e)
        }, e.prototype.add_group = function (e) {
            var t, i, n, a, o, r;
            for (t = this.parsed.length, this.parsed.push({
                array_index: t,
                group: !0,
                label: e.label,
                children: 0,
                disabled: e.disabled
            }), o = e.childNodes, r = [], n = 0, a = o.length; a > n; n++) i = o[n], r.push(this.add_option(i, t, e.disabled));
            return r
        }, e.prototype.add_option = function (e, t, i) {
            return "OPTION" === e.nodeName.toUpperCase() ? ("" !== e.text ? (null != t && (this.parsed[t].children += 1), this.parsed.push({
                array_index: this.parsed.length,
                options_index: this.options_index,
                value: e.value,
                text: e.text,
                html: e.innerHTML,
                selected: e.selected,
                disabled: i === !0 ? i : e.disabled,
                group_array_index: t,
                classes: e.className,
                style: e.style.cssText
            })) : this.parsed.push({
                array_index: this.parsed.length,
                options_index: this.options_index,
                empty: !0
            }), this.options_index += 1) : void 0
        }, e
    }(), e.select_to_array = function (t) {
        var i, n, a, o, r;
        for (n = new e, r = t.childNodes, a = 0, o = r.length; o > a; a++) i = r[a], n.add_node(i);
        return n.parsed
    }, this.SelectParser = e
}.call(this),
function () {
    var e, t;
    t = this, e = function () {
        function e(t, i) {
            this.form_field = t, this.options = null != i ? i : {}, e.browser_is_supported() && (this.is_multiple = this.form_field.multiple, this.set_default_text(), this.set_default_values(), this.setup(), this.set_up_html(), this.register_observers(), this.finish_setup())
        }
        return e.prototype.set_default_values = function () {
            var e = this;
            return this.click_test_action = function (t) {
                return e.test_active_click(t)
            }, this.activate_action = function (t) {
                return e.activate_field(t)
            }, this.active_field = !1, this.mouse_on_container = !1, this.results_showing = !1, this.result_highlighted = null, this.result_single_selected = null, this.allow_single_deselect = null != this.options.allow_single_deselect && null != this.form_field.options[0] && "" === this.form_field.options[0].text ? this.options.allow_single_deselect : !1, this.disable_search_threshold = this.options.disable_search_threshold || 0, this.disable_search = this.options.disable_search || !1, this.enable_split_word_search = null != this.options.enable_split_word_search ? this.options.enable_split_word_search : !0, this.search_contains = this.options.search_contains || !1, this.single_backstroke_delete = this.options.single_backstroke_delete || !1, this.max_selected_options = this.options.max_selected_options || 1 / 0, this.inherit_select_classes = this.options.inherit_select_classes || !1
        }, e.prototype.set_default_text = function () {
            return this.default_text = this.form_field.getAttribute("data-placeholder") ? this.form_field.getAttribute("data-placeholder") : this.is_multiple ? this.options.placeholder_text_multiple || this.options.placeholder_text || e.default_multiple_text : this.options.placeholder_text_single || this.options.placeholder_text || e.default_single_text, this.results_none_found = this.form_field.getAttribute("data-no_results_text") || this.options.no_results_text || e.default_no_result_text
        }, e.prototype.mouse_enter = function () {
            return this.mouse_on_container = !0
        }, e.prototype.mouse_leave = function () {
            return this.mouse_on_container = !1
        }, e.prototype.input_focus = function () {
            var e = this;
            if (this.is_multiple) {
                if (!this.active_field) return setTimeout(function () {
                    return e.container_mousedown()
                }, 50)
            } else if (!this.active_field) return this.activate_field()
        }, e.prototype.input_blur = function () {
            var e = this;
            return this.mouse_on_container ? void 0 : (this.active_field = !1, setTimeout(function () {
                return e.blur_test()
            }, 100))
        }, e.prototype.results_option_build = function (e) {
            var t, i, n, a, o;
            for (t = "", o = this.results_data, n = 0, a = o.length; a > n; n++) i = o[n], i.group && i.search_match ? t += this.result_add_group(i) : !i.empty && i.search_match && (t += this.result_add_option(i)), (null != e ? e.first : void 0) && (i.selected && this.is_multiple ? this.choice_build(i) : i.selected && !this.is_multiple && this.single_set_selected_text(i.text));
            return t
        }, e.prototype.result_add_option = function (e) {
            var t, i;
            return e.dom_id = this.container_id + "_o_" + e.array_index, t = [], e.disabled || e.selected && this.is_multiple || t.push("active-result"), !e.disabled || e.selected && this.is_multiple || t.push("disabled-result"), e.selected && t.push("result-selected"), null != e.group_array_index && t.push("group-option"), "" !== e.classes && t.push(e.classes), i = "" !== e.style.cssText ? ' style="' + e.style + '"' : "", '<li id="' + e.dom_id + '" class="' + t.join(" ") + '"' + i + ">" + e.search_text + "</li>"
        }, e.prototype.results_update_field = function () {
            return this.set_default_text(), this.is_multiple || this.results_reset_cleanup(), this.result_clear_highlight(), this.result_single_selected = null, this.results_build()
        }, e.prototype.results_toggle = function () {
            return this.results_showing ? this.results_hide() : this.results_show()
        }, e.prototype.results_search = function () {
            return this.results_showing ? this.winnow_results() : this.results_show()
        }, e.prototype.winnow_results = function () {
            var e, t, i, n, a, o, r, s, l, c, u, d, h, p, f;
            for (this.no_results_clear(), o = 0, r = this.get_search_text(), a = this.search_contains ? "" : "^", n = new RegExp(a + r.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&"), "i"), c = new RegExp(r.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&"), "i"), f = this.results_data, u = 0, h = f.length; h > u; u++)
                if (e = f[u], !e.empty)
                    if (e.group) e.search_match = !1;
                    else {
                        if (e.search_match = !1, n.test(e.html)) e.search_match = !0, o += 1;
                        else if (this.enable_split_word_search && (e.html.indexOf(" ") >= 0 || 0 === e.html.indexOf("[")) && (i = e.html.replace(/\[|\]/g, "").split(" "), i.length))
                            for (d = 0, p = i.length; p > d; d++) t = i[d], n.test(t) && (e.search_match = !0, o += 1);
                        e.search_match && (r.length ? (s = e.html.search(c), l = e.html.substr(0, s + r.length) + "</em>" + e.html.substr(s + r.length), l = l.substr(0, s) + "<em>" + l.substr(s)) : l = e.html, e.search_text = l, null != e.group_array_index && (this.results_data[e.group_array_index].search_match = !0))
                    }
            return 1 > o && r.length ? (this.update_results_content(""), this.no_results(r)) : (this.update_results_content(this.results_option_build()), this.winnow_results_set_highlight())
        }, e.prototype.choices_count = function () {
            var e, t, i, n;
            if (null != this.selected_option_count) return this.selected_option_count;
            for (this.selected_option_count = 0, n = this.form_field.options, t = 0, i = n.length; i > t; t++) e = n[t], e.selected && (this.selected_option_count += 1);
            return this.selected_option_count
        }, e.prototype.choices_click = function (e) {
            return e.preventDefault(), this.results_showing || this.is_disabled ? void 0 : this.results_show()
        }, e.prototype.keyup_checker = function (e) {
            var t, i;
            switch (t = null != (i = e.which) ? i : e.keyCode, this.search_field_scale(), t) {
            case 8:
                if (this.is_multiple && this.backstroke_length < 1 && this.choices_count() > 0) return this.keydown_backstroke();
                if (!this.pending_backstroke) return this.result_clear_highlight(), this.results_search();
                break;
            case 13:
                if (e.preventDefault(), this.results_showing) return this.result_select(e);
                break;
            case 27:
                return this.results_showing && this.results_hide(), !0;
            case 9:
            case 38:
            case 40:
            case 16:
            case 91:
            case 17:
                break;
            default:
                return this.results_search()
            }
        }, e.prototype.generate_field_id = function () {
            var e;
            return e = this.generate_random_id(), this.form_field.id = e, e
        }, e.prototype.generate_random_char = function () {
            var e, t, i;
            return e = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", i = Math.floor(Math.random() * e.length), t = e.substring(i, i + 1)
        }, e.prototype.container_width = function () {
            return null != this.options.width ? this.options.width : "" + this.form_field.offsetWidth + "px"
        }, e.browser_is_supported = function () {
            var e;
            return "Microsoft Internet Explorer" === window.navigator.appName ? null !== (e = document.documentMode) && e >= 8 : !0
        }, e.default_multiple_text = "Select Some Options", e.default_single_text = "Select an Option", e.default_no_result_text = "No results match", e
    }(), t.AbstractChosen = e
}.call(this),
function () {
    var e, t, i, n, a = {}.hasOwnProperty,
        o = function (e, t) {
            function i() {
                this.constructor = e
            }
            for (var n in t) a.call(t, n) && (e[n] = t[n]);
            return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
        };
    i = this, e = jQuery, e.fn.extend({
        chosen: function (i) {
            return AbstractChosen.browser_is_supported() ? this.each(function () {
                var n;
                return n = e(this), n.hasClass("chzn-done") ? void 0 : n.data("chosen", new t(this, i))
            }) : this
        }
    }), t = function (t) {
        function a() {
            return n = a.__super__.constructor.apply(this, arguments)
        }
        return o(a, t), a.prototype.setup = function () {
            return this.form_field_jq = e(this.form_field), this.current_selectedIndex = this.form_field.selectedIndex, this.is_rtl = this.form_field_jq.hasClass("chzn-rtl")
        }, a.prototype.finish_setup = function () {
            return this.form_field_jq.addClass("chzn-done")
        }, a.prototype.set_up_html = function () {
            var t, i;
            return this.container_id = this.form_field.id.length ? this.form_field.id.replace(/[^\w]/g, "_") : this.generate_field_id(), this.container_id += "_chzn", t = ["chzn-container"], t.push("chzn-container-" + (this.is_multiple ? "multi" : "single")), this.inherit_select_classes && this.form_field.className && t.push(this.form_field.className), this.is_rtl && t.push("chzn-rtl"), i = {
                id: this.container_id,
                "class": t.join(" "),
                title: this.form_field.title
            }, this.container = e("<div />", i), this.is_multiple ? this.container.html('<ul class="chzn-choices"><li class="search-field"><input type="text" value="' + this.default_text + '" class="default" autocomplete="off" style="width:25px;" /></li></ul><div class="chzn-drop"><ul class="chzn-results"></ul></div>') : this.container.html('<a href="javascript:void(0)" class="chzn-single chzn-default" tabindex="-1"><span>' + this.default_text + '</span><div><b></b></div></a><div class="chzn-drop"><div class="chzn-search"><input type="text" autocomplete="off" /></div><ul class="chzn-results"></ul></div>'), this.form_field_jq.hide().after(this.container), this.dropdown = this.container.find("div.chzn-drop").first(), this.search_field = this.container.find("input").first(), this.search_results = this.container.find("ul.chzn-results").first(), this.search_field_scale(), this.search_no_results = this.container.find("li.no-results").first(), this.is_multiple ? (this.search_choices = this.container.find("ul.chzn-choices").first(), this.search_container = this.container.find("li.search-field").first()) : (this.search_container = this.container.find("div.chzn-search").first(), this.selected_item = this.container.find(".chzn-single").first()), this.results_build(), this.set_tab_index(), this.set_label_behavior(), this.form_field_jq.trigger("liszt:ready", {
                chosen: this
            })
        }, a.prototype.register_observers = function () {
            var e = this;
            return this.container.mousedown(function (t) {
                e.container_mousedown(t)
            }), this.container.mouseup(function (t) {
                e.container_mouseup(t)
            }), this.container.mouseenter(function (t) {
                e.mouse_enter(t)
            }), this.container.mouseleave(function (t) {
                e.mouse_leave(t)
            }), this.search_results.mouseup(function (t) {
                e.search_results_mouseup(t)
            }), this.search_results.mouseover(function (t) {
                e.search_results_mouseover(t)
            }), this.search_results.mouseout(function (t) {
                e.search_results_mouseout(t)
            }), this.search_results.bind("mousewheel DOMMouseScroll", function (t) {
                e.search_results_mousewheel(t)
            }), this.form_field_jq.bind("liszt:updated", function (t) {
                e.results_update_field(t)
            }), this.form_field_jq.bind("liszt:activate", function (t) {
                e.activate_field(t)
            }), this.form_field_jq.bind("liszt:open", function (t) {
                e.container_mousedown(t)
            }), this.search_field.blur(function (t) {
                e.input_blur(t)
            }), this.search_field.keyup(function (t) {
                e.keyup_checker(t)
            }), this.search_field.keydown(function (t) {
                e.keydown_checker(t)
            }), this.search_field.focus(function (t) {
                e.input_focus(t)
            }), this.is_multiple ? this.search_choices.click(function (t) {
                e.choices_click(t)
            }) : this.container.click(function (e) {
                e.preventDefault()
            })
        }, a.prototype.search_field_disabled = function () {
            return this.is_disabled = this.form_field_jq[0].disabled, this.is_disabled ? (this.container.addClass("chzn-disabled"), this.search_field[0].disabled = !0, this.is_multiple || this.selected_item.unbind("focus", this.activate_action), this.close_field()) : (this.container.removeClass("chzn-disabled"), this.search_field[0].disabled = !1, this.is_multiple ? void 0 : this.selected_item.bind("focus", this.activate_action))
        }, a.prototype.container_mousedown = function (t) {
            return this.is_disabled || (t && "mousedown" === t.type && !this.results_showing && t.preventDefault(), null != t && e(t.target).hasClass("search-choice-close")) ? void 0 : (this.active_field ? this.is_multiple || !t || e(t.target)[0] !== this.selected_item[0] && !e(t.target).parents("a.chzn-single").length || (t.preventDefault(), this.results_toggle()) : (this.is_multiple && this.search_field.val(""), e(document).click(this.click_test_action), this.results_show()), this.activate_field())
        }, a.prototype.container_mouseup = function (e) {
            return "ABBR" !== e.target.nodeName || this.is_disabled ? void 0 : this.results_reset(e)
        }, a.prototype.search_results_mousewheel = function (e) {
            var t, i, n;
            return t = -(null != (i = e.originalEvent) ? i.wheelDelta : void 0) || (null != (n = e.originialEvent) ? n.detail : void 0), null != t ? (e.preventDefault(), "DOMMouseScroll" === e.type && (t = 40 * t), this.search_results.scrollTop(t + this.search_results.scrollTop())) : void 0
        }, a.prototype.blur_test = function () {
            return !this.active_field && this.container.hasClass("chzn-container-active") ? this.close_field() : void 0
        }, a.prototype.close_field = function () {
            return e(document).unbind("click", this.click_test_action), this.active_field = !1, this.results_hide(), this.container.removeClass("chzn-container-active"), this.clear_backstroke(), this.show_search_field_default(), this.search_field_scale()
        }, a.prototype.activate_field = function () {
            return this.container.addClass("chzn-container-active"), this.active_field = !0, this.search_field.val(this.search_field.val()), this.search_field.focus()
        }, a.prototype.test_active_click = function (t) {
            return e(t.target).parents("#" + this.container_id).length ? this.active_field = !0 : this.close_field()
        }, a.prototype.results_build = function () {
            return this.parsing = !0, this.selected_option_count = null, this.results_data = i.SelectParser.select_to_array(this.form_field), this.is_multiple ? this.search_choices.find("li.search-choice").remove() : this.is_multiple || (this.single_set_selected_text(), this.disable_search || this.form_field.options.length <= this.disable_search_threshold ? (this.search_field[0].readOnly = !0, this.container.addClass("chzn-container-single-nosearch")) : (this.search_field[0].readOnly = !1, this.container.removeClass("chzn-container-single-nosearch"))), this.update_results_content(this.results_option_build({
                first: !0
            })), this.search_field_disabled(), this.show_search_field_default(), this.search_field_scale(), this.parsing = !1
        }, a.prototype.result_add_group = function (t) {
            return t.dom_id = this.container_id + "_g_" + t.array_index, '<li id="' + t.dom_id + '" class="group-result">' + e("<div />").text(t.label).html() + "</li>"
        }, a.prototype.result_do_highlight = function (e) {
            var t, i, n, a, o;
            if (e.length) {
                if (this.result_clear_highlight(), this.result_highlight = e, this.result_highlight.addClass("highlighted"), n = parseInt(this.search_results.css("maxHeight"), 10), o = this.search_results.scrollTop(), a = n + o, i = this.result_highlight.position().top + this.search_results.scrollTop(), t = i + this.result_highlight.outerHeight(), t >= a) return this.search_results.scrollTop(t - n > 0 ? t - n : 0);
                if (o > i) return this.search_results.scrollTop(i)
            }
        }, a.prototype.result_clear_highlight = function () {
            return this.result_highlight && this.result_highlight.removeClass("highlighted"), this.result_highlight = null
        }, a.prototype.results_show = function () {
            return this.is_multiple && this.max_selected_options <= this.choices_count() ? (this.form_field_jq.trigger("liszt:maxselected", {
                chosen: this
            }), !1) : (this.container.addClass("chzn-with-drop"), this.form_field_jq.trigger("liszt:showing_dropdown", {
                chosen: this
            }), this.results_showing = !0, this.search_field.focus(), this.search_field.val(this.search_field.val()), this.winnow_results())
        }, a.prototype.update_results_content = function (e) {
            return this.search_results.html(e)
        }, a.prototype.results_hide = function () {
            return this.results_showing && (this.result_clear_highlight(), this.container.removeClass("chzn-with-drop"), this.form_field_jq.trigger("liszt:hiding_dropdown", {
                chosen: this
            })), this.results_showing = !1
        }, a.prototype.set_tab_index = function () {
            var e;
            return this.form_field_jq.attr("tabindex") ? (e = this.form_field_jq.attr("tabindex"), this.form_field_jq.attr("tabindex", -1), this.search_field.attr("tabindex", e)) : void 0
        }, a.prototype.set_label_behavior = function () {
            var t = this;
            return this.form_field_label = this.form_field_jq.parents("label"), !this.form_field_label.length && this.form_field.id.length && (this.form_field_label = e("label[for='" + this.form_field.id + "']")), this.form_field_label.length > 0 ? this.form_field_label.click(function (e) {
                return t.is_multiple ? t.container_mousedown(e) : t.activate_field()
            }) : void 0
        }, a.prototype.show_search_field_default = function () {
            return this.is_multiple && this.choices_count() < 1 && !this.active_field ? (this.search_field.val(this.default_text), this.search_field.addClass("default")) : (this.search_field.val(""), this.search_field.removeClass("default"))
        }, a.prototype.search_results_mouseup = function (t) {
            var i;
            return i = e(t.target).hasClass("active-result") ? e(t.target) : e(t.target).parents(".active-result").first(), i.length ? (this.result_highlight = i, this.result_select(t), this.search_field.focus()) : void 0
        }, a.prototype.search_results_mouseover = function (t) {
            var i;
            return i = e(t.target).hasClass("active-result") ? e(t.target) : e(t.target).parents(".active-result").first(), i ? this.result_do_highlight(i) : void 0
        }, a.prototype.search_results_mouseout = function (t) {
            return e(t.target).hasClass("active-result") ? this.result_clear_highlight() : void 0
        }, a.prototype.choice_build = function (t) {
            var i, n, a = this;
            return i = e("<li />", {
                "class": "search-choice"
            }).html("<span>" + t.html + "</span>"), t.disabled ? i.addClass("search-choice-disabled") : (n = e("<a />", {
                href: "#",
                "class": "search-choice-close",
                rel: t.array_index
            }), n.click(function (e) {
                return a.choice_destroy_link_click(e)
            }), i.append(n)), this.search_container.before(i)
        }, a.prototype.choice_destroy_link_click = function (t) {
            return t.preventDefault(), t.stopPropagation(), this.is_disabled ? void 0 : this.choice_destroy(e(t.target))
        }, a.prototype.choice_destroy = function (e) {
            return this.result_deselect(e.attr("rel")) ? (this.show_search_field_default(), this.is_multiple && this.choices_count() > 0 && this.search_field.val().length < 1 && this.results_hide(), e.parents("li").first().remove(), this.search_field_scale()) : void 0
        }, a.prototype.results_reset = function () {
            return this.form_field.options[0].selected = !0, this.selected_option_count = null, this.single_set_selected_text(), this.show_search_field_default(), this.results_reset_cleanup(), this.form_field_jq.trigger("change"), this.active_field ? this.results_hide() : void 0
        }, a.prototype.results_reset_cleanup = function () {
            return this.current_selectedIndex = this.form_field.selectedIndex, this.selected_item.find("abbr").remove()
        }, a.prototype.result_select = function (e) {
            var t, i, n, a;
            return this.result_highlight ? (t = this.result_highlight, i = t.attr("id"), this.result_clear_highlight(), this.is_multiple && this.max_selected_options <= this.choices_count() ? (this.form_field_jq.trigger("liszt:maxselected", {
                chosen: this
            }), !1) : (this.is_multiple ? t.removeClass("active-result") : (this.search_results.find(".result-selected").removeClass("result-selected"), this.result_single_selected = t), t.addClass("result-selected"), a = i.substr(i.lastIndexOf("_") + 1), n = this.results_data[a], n.selected = !0, this.form_field.options[n.options_index].selected = !0, this.selected_option_count = null, this.is_multiple ? this.choice_build(n) : this.single_set_selected_text(n.text), (e.metaKey || e.ctrlKey) && this.is_multiple || this.results_hide(), this.search_field.val(""), (this.is_multiple || this.form_field.selectedIndex !== this.current_selectedIndex) && this.form_field_jq.trigger("change", {
                selected: this.form_field.options[n.options_index].value
            }), this.current_selectedIndex = this.form_field.selectedIndex, this.search_field_scale())) : void 0
        }, a.prototype.single_set_selected_text = function (e) {
            return null == e && (e = this.default_text), e === this.default_text ? this.selected_item.addClass("chzn-default") : (this.single_deselect_control_build(), this.selected_item.removeClass("chzn-default")), this.selected_item.find("span").text(e)
        }, a.prototype.result_deselect = function (t) {
            var i, n;
            return n = this.results_data[t], this.form_field.options[n.options_index].disabled ? !1 : (n.selected = !1, this.form_field.options[n.options_index].selected = !1, this.selected_option_count = null, i = e("#" + this.container_id + "_o_" + t), i.removeClass("result-selected").addClass("active-result").show(), this.result_clear_highlight(), this.results_showing && this.winnow_results(), this.form_field_jq.trigger("change", {
                deselected: this.form_field.options[n.options_index].value
            }), this.search_field_scale(), !0)
        }, a.prototype.single_deselect_control_build = function () {
            return this.allow_single_deselect ? (this.selected_item.find("abbr").length || this.selected_item.find("span").first().after('<abbr class="search-choice-close"></abbr>'), this.selected_item.addClass("chzn-single-with-deselect")) : void 0
        }, a.prototype.get_search_text = function () {
            return this.search_field.val() === this.default_text ? "" : e("<div/>").text(e.trim(this.search_field.val())).html()
        }, a.prototype.winnow_results_set_highlight = function () {
            var e, t;
            return t = this.is_multiple ? [] : this.search_results.find(".result-selected.active-result"), e = t.length ? t.first() : this.search_results.find(".active-result").first(), null != e ? this.result_do_highlight(e) : void 0
        }, a.prototype.no_results = function (t) {
            var i;
            return i = e('<li class="no-results">' + this.results_none_found + ' "<span></span>"</li>'), i.find("span").first().html(t), this.search_results.append(i)
        }, a.prototype.no_results_clear = function () {
            return this.search_results.find(".no-results").remove()
        }, a.prototype.keydown_arrow = function () {
            var e;
            return this.results_showing && this.result_highlight ? (e = this.result_highlight.nextAll("li.active-result").first()) ? this.result_do_highlight(e) : void 0 : this.results_show()
        }, a.prototype.keyup_arrow = function () {
            var e;
            return this.results_showing || this.is_multiple ? this.result_highlight ? (e = this.result_highlight.prevAll("li.active-result"), e.length ? this.result_do_highlight(e.first()) : (this.choices_count() > 0 && this.results_hide(), this.result_clear_highlight())) : void 0 : this.results_show()
        }, a.prototype.keydown_backstroke = function () {
            var e;
            return this.pending_backstroke ? (this.choice_destroy(this.pending_backstroke.find("a").first()), this.clear_backstroke()) : (e = this.search_container.siblings("li.search-choice").last(), e.length && !e.hasClass("search-choice-disabled") ? (this.pending_backstroke = e, this.single_backstroke_delete ? this.keydown_backstroke() : this.pending_backstroke.addClass("search-choice-focus")) : void 0)
        }, a.prototype.clear_backstroke = function () {
            return this.pending_backstroke && this.pending_backstroke.removeClass("search-choice-focus"), this.pending_backstroke = null
        }, a.prototype.keydown_checker = function (e) {
            var t, i;
            switch (t = null != (i = e.which) ? i : e.keyCode, this.search_field_scale(), 8 !== t && this.pending_backstroke && this.clear_backstroke(), t) {
            case 8:
                this.backstroke_length = this.search_field.val().length;
                break;
            case 9:
                this.results_showing && !this.is_multiple && this.result_select(e), this.mouse_on_container = !1;
                break;
            case 13:
                e.preventDefault();
                break;
            case 38:
                e.preventDefault(), this.keyup_arrow();
                break;
            case 40:
                e.preventDefault(), this.keydown_arrow()
            }
        }, a.prototype.search_field_scale = function () {
            var t, i, n, a, o, r, s, l;
            if (this.is_multiple) {
                for (i = 0, r = 0, a = "position:absolute; left: -1000px; top: -1000px; display:none;", o = ["font-size", "font-style", "font-weight", "font-family", "line-height", "text-transform", "letter-spacing"], s = 0, l = o.length; l > s; s++) n = o[s], a += n + ":" + this.search_field.css(n) + ";";
                return t = e("<div />", {
                    style: a
                }), t.text(this.search_field.val()), e("body").append(t), r = t.width() + 25, t.remove(), this.f_width || (this.f_width = this.container.outerWidth()), r > this.f_width - 10 && (r = this.f_width - 10), this.search_field.css({
                    width: r + "px"
                })
            }
        }, a.prototype.generate_random_id = function () {
            var t;
            for (t = "sel" + this.generate_random_char() + this.generate_random_char() + this.generate_random_char(); e("#" + t).length > 0;) t += this.generate_random_char();
            return t
        }, a
    }(AbstractChosen), i.Chosen = t
}.call(this);